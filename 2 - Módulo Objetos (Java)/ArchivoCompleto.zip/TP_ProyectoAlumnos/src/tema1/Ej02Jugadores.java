
package tema1;

//Paso 1: Importar la funcionalidad para lectura de datos
import PaqueteLectura.Lector;

public class Ej02Jugadores {

  
    public static void main(String[] args) {
        //Paso 2: Declarar la variable vector de double 
        double [] vector ;        
        
        //Paso 3: Crear el vector para 15 double 
        int DF = 15;
        vector = new double [DF];
        
        //Paso 4: Declarar indice y variables auxiliares a usar
        int i;
        double alt;
        double suma=0;
        
        //Paso 6: Ingresar 15 numeros (altura), cargarlos en el vector, ir calculando la suma de alturas
       
        for (i=0; i<DF; i++){
            alt = Lector.leerDouble();
            suma = suma+alt;
            vector[i] = alt;
        }
        
        for (i=0; i<DF; i++) System.out.println(vector[i] + " ");
        
        //Paso 7: Calcular el promedio de alturas, informarlo
        double promedio = (suma/DF);
        System.out.println("EL promedio de altura entre los 15 jugadores es de: " + promedio);

        //Paso 8: Recorrer el vector calculando lo pedido (cant. alturas que están por encima del promedio)
        int cant=0;
        for (i=0; i<DF; i++) {
            if (vector[i] > promedio)
            cant = cant+=1;
        }
        
        //Paso 9: Informar la cantidad.
        System.out.println("La cantidad de jugadores que superan la altura promedio es: " + cant);
    }
    
}
