/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema1;

//Paso 1. importar la funcionalidad para generar datos aleatorios
import PaqueteLectura.GeneradorAleatorio;

import PaqueteLectura.Lector;

public class Ej03Matrices {

    public static void main(String[] args) {
	//Paso 2. iniciar el generador aleatorio     
        GeneradorAleatorio.iniciar();
        
        //Paso 3. definir la matriz de enteros de 5x5 e iniciarla con nros. aleatorios 
        int DF=5;
        int[][] matriz = new int[DF][DF];
        
        int i,j;
        for (i=0; i<DF; i++)
            for (j=0; j<DF; j++)
                matriz [i][j] = GeneradorAleatorio.generarInt(30);
        
        //Paso 4. mostrar el contenido de la matriz en consola
        for (i=0; i<DF; i++){
            for (j=0; j<DF; j++) 
                System.out.print(matriz [i][j] + " ");
            System.out.println();
            }
        
        //Paso 5. calcular e informar la suma de los elementos de la fila 1
        int suma=0;
        for (j=0; j<DF; j++)
            suma = suma + matriz[1][j];
        System.out.println("El valor de la suma total de la fila 1 es: "+suma);
        
        //Paso 6. generar un vector de 5 posiciones donde cada posición j contiene la suma de los elementos de la columna j de la matriz. 
        int[] vector = new int[DF];
        for (j=0; j<DF; j++) {
            suma=0; 
            for (i=0; i<DF; i++)
                suma = suma + matriz[i][j];
            vector[j] = suma;
        }
        //        Luego, imprima el vector.
        for (j=0; j<DF; j++)
               System.out.print(vector[j] + " ");
        
        //Paso 7. lea un valor entero e indique si se encuentra o no en la matriz. En caso de encontrarse indique su ubicación (fila y columna)
        //   y en caso contrario imprima "No se encontró el elemento".
        System.out.println();
        System.out.println("Ingresar un numero a buscar en la matriz: ");
        int elem = Lector.leerInt();
        boolean encontro=false;
        int fila=0, columna=0;
        while ((fila<DF) && (encontro == false)) {
            columna=0;
            while ((columna<DF) && (encontro == false)) {
                if(matriz[fila][columna] == elem) 
                    encontro = true;
                columna = columna + 1;
               }
            
            fila = fila + 1;
            }
        
        if (encontro == true) 
            System.out.println("El elemento fue encontrado en la fila "+ fila +", columna "+ columna);
        else
            System.out.println("No se encontró el elemento"); 
    }
}
