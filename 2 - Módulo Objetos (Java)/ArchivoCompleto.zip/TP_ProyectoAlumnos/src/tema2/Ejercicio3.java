/*
Se realizará un casting para un programa de TV. El casting durará a lo sumo 5 días y en
cada día se entrevistarán a 8 personas en distinto turno.

a) Simular el proceso de inscripción de personas al casting. A cada persona se le pide
nombre, DNI y edad y se la debe asignar en un día y turno de la siguiente manera: las
personas primero completan el primer día en turnos sucesivos, luego el segundo día y así
siguiendo. La inscripción finaliza al llegar una persona con nombre “ZZZ” o al cubrirse los
40 cupos de casting.

Una vez finalizada la inscripción:
b) Informar para cada día y turno asignado, el nombre de la persona a entrevistar.

NOTA: utilizar la clase Persona. Pensar en la estructura de datos a utilizar. Para comparar
Strings use el método equals.
 */
package tema2;

import PaqueteLectura.GeneradorAleatorio;
import PaqueteLectura.Lector;
        
public class Ejercicio3 {
    
    public static void main(String[] args) {
        int filas=5, columnas=8;
        Persona [][] matriz = new Persona [filas][columnas];
        Persona p = new Persona();
        p.setNombre(Lector.leerString());
        int DL=0, DF=columnas*filas;
        while ((DL < DF)&&(!p.getNombre().equals("ZZZ"))) {
            matriz[DL/columnas][DL%columnas] = new Persona(p.getNombre(),GeneradorAleatorio.generarInt(20000),GeneradorAleatorio.generarInt(40));
            DL++;
            p.setNombre(Lector.leerString());
        }
        
        for (int i=0; i<DL; i++)
            System.out.println("Dia: "+i/columnas+", Turno: "+i%columnas+", Nombre: "+matriz[i/columnas][i%columnas].getNombre()+" |");
    }
    
}
