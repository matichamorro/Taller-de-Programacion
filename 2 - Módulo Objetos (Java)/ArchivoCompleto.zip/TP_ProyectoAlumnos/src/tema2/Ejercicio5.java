/*
 Implemente un programa que cargue un vector con a lo sumo 20 partidos disputados en
el campeonato. La información de cada partido se lee desde teclado hasta ingresar uno con
nombre de visitante “ZZZ” o alcanzar los 20 partidos. Luego de la carga:
- Para cada partido, armar e informar una representación String del estilo:
{EQUIPO-LOCAL golesLocal VS EQUIPO-VISITANTE golesVisitante }
- Calcular e informar la cantidad de partidos que ganó River.
- Calcular e informar el total de goles que realizó Boca jugando de local.
 */
package tema2;

/**
 * @author Matias Chamorro
 */

import PaqueteLectura.Lector;
import PaqueteLectura.GeneradorAleatorio;

public class Ejercicio5 {
    
    public static void main(String[] args) {
        int DL=0, DF=20;
        Partido [] vector = new Partido [DF];
        Partido par = new Partido();
        
        par.setVisitante(Lector.leerString());
        while ((DL<DF)&&(!par.getVisitante().equals("ZZZ"))) {
            vector[DL] = new Partido(Lector.leerString(),par.getVisitante(),GeneradorAleatorio.generarInt(5),GeneradorAleatorio.generarInt(5));
            DL++;
            par.setVisitante(Lector.leerString());
        }
        
        int cantRiver=0, golesBocaLocal=0;
        for (int i=0; i<DL; i++) {
            System.out.println(vector[i].getLocal()+" "+vector[i].getGolesLocal()+" - "+vector[i].getVisitante()+" "+vector[i].getGolesVisitante());
            if ((vector[i].hayGanador()) && (vector[i].getGanador().equals("River")))
                cantRiver++;
            if (vector[i].getLocal().equals("Boca"))
                golesBocaLocal = golesBocaLocal + vector[i].getGolesLocal();           
        }
            
        System.out.println("River gano "+cantRiver+" partidos.");
        System.out.println("Boca metio "+golesBocaLocal+" goles jugando de local.");
    }
    
}
