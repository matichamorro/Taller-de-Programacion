/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema2;

import PaqueteLectura.GeneradorAleatorio;

/**
 *
 * @author Matias Chamorro
 */
public class Ejercicio2 {
    
     public static void main(String[] args) {
        int DF=15, DL=0;
        Persona vector [] = new Persona[DF];
        
        String nombre;
        int edad=GeneradorAleatorio.generarInt(70), DNI;
        
        while ((DL<DF) && (edad != 0)) {
            nombre = GeneradorAleatorio.generarString(5);
            DNI = 20000000 + GeneradorAleatorio.generarInt(1000000);
            
            vector[DL] = new Persona(nombre,DNI,edad);
            System.out.println(vector[DL].toString());
            
            edad=GeneradorAleatorio.generarInt(70);
            DL++;
             }
        
        int i=0, mayores=0, min=30000001, pos = 16;
        while (i <= DL) {
            if (vector[i].getEdad() > 65) 
                mayores++;
            if(vector[i].getDNI() > min)
                pos = i;
        }
        System.out.println("La cantidad de mayores de 65 años es: "+ mayores);
        if (pos != 16)
            System.out.println(vector[pos].toString());
        else
            System.out.println("El vector esta vacio");
    }

}
