/*
4- Sobre un nuevo programa, modifique el ejercicio anterior para considerar que:

a) Durante el proceso de inscripción se pida a cada persona sus datos (nombre, DNI, edad)
y el día en que se quiere presentar al casting. La persona debe ser inscripta en ese día, en el
siguiente turno disponible. En caso de no existir un turno en ese día, informe la situación.
La inscripción finaliza al llegar una persona con nombre “ZZZ” o al cubrirse los 40 cupos
de casting.

Una vez finalizada la inscripción:
b) Informar para cada día: la cantidad de inscriptos al casting ese día y el nombre de la
persona a entrevistar en cada turno asignado.
 */
package tema2;

import PaqueteLectura.Lector;
import PaqueteLectura.GeneradorAleatorio;
        /**
 * @author Matias Chamorro
 */
public class Ejercicio4 {
    
    public static void main(String[] args) {
       int filas=5, columnas=8;
       Persona [][] matriz = new Persona[filas][columnas];
       int [] vectorDL = new int [filas];
       
       Persona per = new Persona();
       int DL=0,DF=filas*columnas, diaPedido;
       
       per.setNombre(Lector.leerString());
       
       while ((DL<DF)&&(!per.getNombre().equals("ZZZ"))) {
           diaPedido = Lector.leerInt();
           if (vectorDL[diaPedido-1] < columnas) {
               matriz[diaPedido-1][vectorDL[diaPedido-1]] = new Persona(per.getNombre(),GeneradorAleatorio.generarInt(20000),GeneradorAleatorio.generarInt(40));
               System.out.println("Recien leido: "+ matriz[diaPedido-1][vectorDL[diaPedido-1]].toString());
               vectorDL[diaPedido-1]++;
               DL++;
           }
           else
                System.out.println("No se pueden inscribir mas personas en el dia "+ diaPedido);
           per.setNombre(Lector.leerString());
        }
       
       for (int i=0; i<filas; i++)
            for (int j=0; j<vectorDL[i]; j++)
                System.out.println("Dia: "+(i+1)+", Turno: "+(j+1)+", Nombre: "+matriz[i][j%columnas].getNombre()+" |");              
                      
    }
    
}
