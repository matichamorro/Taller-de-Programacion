/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 * @author Mati
 */
public abstract class Empleado {
    private String nombre;
    private double sueldo;
    private double antiguedad;
    
    public Empleado(String unNom, double unSueldo, double unaAnt){
        setNombre(unNom);
        setSueldo(unSueldo);
        setAntiguedad(unaAnt);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public double getAntiguedad() {
        return antiguedad;
    }

    public void setAntiguedad(double antiguedad) {
        this.antiguedad = antiguedad;
    }
    
    public abstract double calcularEfectividad();
    public abstract double calcularSueldoACobrar();
    
    public String toString(){
        return "Nombre: "+ getNombre() +
              " Sueldo: "+ calcularSueldoACobrar() +
              " Efectividad: "+ calcularEfectividad();
    }
}
