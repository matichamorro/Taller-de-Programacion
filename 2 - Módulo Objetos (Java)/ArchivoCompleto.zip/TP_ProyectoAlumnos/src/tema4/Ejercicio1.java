/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Win10 1909
 */
public class Ejercicio1 {

    public static void main(String[] args) {
        Triangulo tri = new Triangulo(5,6,5,"Azul","Roja");
        Circulo cir = new Circulo(5,"Rojo","Negra");
        
        System.out.println(tri.toString());
        System.out.println(cir.toString());
        
        tri.despintar();
        cir.despintar();
        
        System.out.println();
        System.out.println(tri.toString());
        System.out.println(cir.toString());
        
    }
    
}
