/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author alumnos
 */
public class Ejercicio2 {

    public static void main(String[] args) {
        Jugador j = new Jugador("Mati",10000,2,5,10);
        System.out.println(j.calcularSueldoACobrar());
        System.out.println(j.toString());
        
        System.out.println();
        
        Entrenador e = new Entrenador("Ramon",7000,2,3);
        System.out.println(e.calcularSueldoACobrar());
        System.out.println(e.toString());
    }
    
}
