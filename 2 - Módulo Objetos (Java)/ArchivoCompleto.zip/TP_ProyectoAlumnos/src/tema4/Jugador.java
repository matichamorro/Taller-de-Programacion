/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author alumnos
 */
public class Jugador extends Empleado{
    private double partidos;
    private double goles;

    public Jugador(String unNombre,double unSueldo, double unaAnti, double losPartidos, double losGoles){
        super(unNombre,unSueldo,unaAnti);
        setPartidos(losPartidos);
        setGoles(losGoles);
    }
    
    public double getPartidos() {
        return partidos;
    }

    public void setPartidos(double partidos) {
        this.partidos = partidos;
    }

    public double getGoles() {
        return goles;
    }

    public void setGoles(double goles) {
        this.goles = goles;
    }
    
    public double calcularEfectividad(){
        return getGoles()/getPartidos();
    }
    
    public double calcularSueldoACobrar(){
        double aux = getSueldo() * (100 + 10 * getAntiguedad()) /100.0;
        if (calcularEfectividad() > 0.5)
            aux+= getSueldo();
        return aux;
    }
    
}
