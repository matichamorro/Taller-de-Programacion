/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author maria
 */
public class Ejercicio3 {

    public static void main(String[] args) {
        Persona p = new Persona("Mati",47517241,18);
        System.out.println(p.toString());
        
        System.out.println();
        
        Trabajador t = new Trabajador("Ramon",34712321,34,"Carpintero");
        System.out.println(t.toString());
    }
    
}
