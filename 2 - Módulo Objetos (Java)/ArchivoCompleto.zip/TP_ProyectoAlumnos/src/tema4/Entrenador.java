/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 * @author Mati
 */
public class Entrenador extends Empleado{
    private double campeonatos;

    public Entrenador(String unNombre, double unSueldo, double unaAnti,double losCampeonatos){
        super(unNombre,unSueldo,unaAnti);
        setCampeonatos(losCampeonatos);
    }
    
    public double getCampeonatos() {
        return campeonatos;
    }

    public void setCampeonatos(double campeonatos) {
        this.campeonatos = campeonatos;
    }
    
    public double calcularEfectividad(){
        return getCampeonatos()/getAntiguedad();
    }
    
    public double calcularSueldoACobrar(){
        double aux = getSueldo() * (100 + 10 * getAntiguedad()) /100.0;
        if ((getCampeonatos() >= 1)&&(getCampeonatos() <= 4))
            aux+= 5000;
        else if ((getCampeonatos() > 4)&&(getCampeonatos() <=10))
            aux+= 10000;
        else if (getCampeonatos() > 10)
            aux+= 50000;
        return aux;
    }
    
    
}
