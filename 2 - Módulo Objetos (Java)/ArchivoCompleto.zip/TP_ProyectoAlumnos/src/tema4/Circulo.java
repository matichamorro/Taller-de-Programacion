/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 * @author Mati
 */
public class Circulo extends Figura {
    private double radio; 
    
    public Circulo(double unRadio, String unColorR, String unColorL) {
        super(unColorR,unColorL);
        setRadio(unRadio);
    }
    
    public String toString() {
        String aux = super.toString() +
                " Radio: " + radio;
        return aux;
    }
    
    public double calcularArea() {
        return Math.PI * (radio*radio);
    }
    
    public double calcularPerimetro() {
        return Math.PI * radio;
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }
    
}
