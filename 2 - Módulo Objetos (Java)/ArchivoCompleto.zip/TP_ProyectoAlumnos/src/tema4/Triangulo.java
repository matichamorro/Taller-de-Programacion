/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 * @author Mati
 */
public class Triangulo extends Figura {
    private double ladoA;
    private double ladoB;
    private double ladoC;
    
    public Triangulo(double unLadoA,double unLadoB,double unLadoC,String unColorR,String unColorL) {
        super(unColorR,unColorL);
        setLadoA(unLadoA);
        setLadoB(unLadoB);
        setLadoC(unLadoC);
    }

    public String toString() {
        String aux = super.toString() +
                " Lado A: " + getLadoA() +
                " Lado B: " + getLadoB() + 
                " Lado C: " + getLadoC();
        return aux;
    }
    
    public double getLadoA() {
        return ladoA;
    }

    public void setLadoA(double ladoA) {
        this.ladoA = ladoA;
    }

    public double getLadoB() {
        return ladoB;
    }

    public void setLadoB(double ladoB) {
        this.ladoB = ladoB;
    }

    public double getLadoC() {
        return ladoC;
    }

    public void setLadoC(double ladoC) {
        this.ladoC = ladoC;
    }
    
    public double calcularArea() {
        double aux = (ladoA+ladoB+ladoC)/2.0;
        return Math.sqrt(aux*(aux-ladoA)*(aux-ladoB)*(aux-ladoC));
    }
    
    public double calcularPerimetro() {
        return ladoA+ladoB+ladoC;
    }
}
