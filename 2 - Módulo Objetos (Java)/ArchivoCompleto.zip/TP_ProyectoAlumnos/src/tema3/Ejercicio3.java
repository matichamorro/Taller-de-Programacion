/*
3-A- Defina una clase para representar estantes. Un estante almacena a lo sumo 20 libros.
Implemente un constructor que permita iniciar el estante sin libros. 
    Provea métodos para:
(i) devolver la cantidad de libros que almacenados 
(ii) devolver si el estante está lleno
(iii) agregar un libro al estante 
(iv) devolver el libro con un título particular que se recibe.

B- Realice un programa que instancie un estante. Cargue varios libros. A partir del estante,
busque e informe el autor del libro “Mujercitas”.

C- Piense: ¿Qué modificaría en la clase definida para ahora permitir estantes que
almacenen como máximo N libros? ¿Cómo instanciaría el estante?
 */
package tema3;

import PaqueteLectura.GeneradorAleatorio;
import PaqueteLectura.Lector;

/**
 * @author Matias Chamorro
 */
public class Ejercicio3 {

    public static void main(String[] args) {
        // B)
        Estante e = new Estante();
        
        /*
        e.agregarLibro(new  Libro( "Java: A Beginner's Guide",   
                                 "Mcgraw-Hill", 2014,   
                                 new Autor("Herbert Schildt","Nacio el 28 de febrero de 1951","Chicago"), "978-0071809252", 21.72));
        e.agregarLibro(new Libro("Learning Java by Building Android Games",  
                              "CreateSpace Independent Publishing", 
                               new Autor("John Horton","Nacio el 26 de diciembre de 1937","Liverpool"), "978-1512108347"));
        */

        Libro libro = new Libro();
        libro.setTitulo("AAA");
        
        while ((!e.estaLleno())&&(!libro.getTitulo().equals("ZZZ"))) {
            libro = new Libro(Lector.leerString(),"Editorial",(1950 + GeneradorAleatorio.generarInt(65)),
                                 new Autor("Nombre del autor","Biografia del autor","Origen del autor"),"xxx-xxxxxxxxxx", 10.00);
            e.agregarLibro(libro);
        }
        
        System.out.println(e.buscarLibro("Mujercitas").getPrimerAutor());
    }
    
}
