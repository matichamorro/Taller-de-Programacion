/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3;

/**
 * @author Mati
 */
public class Hotel { 
    private int cant;
    private Habitacion[] habitaciones;
    
    public Hotel(int N) {
        cant = N;
        habitaciones = new Habitacion[N];
        for (int i=0; i<N; i++)
            habitaciones[i] = new Habitacion();
    }
    
    public void reservarHabitacion(Persona C, int X) {
        habitaciones[X].setOcupada(true);
        habitaciones[X].setCliente(C);
    }
    
    public void aumentarPrecios(double unMonto) {
        for (int i=0; i<cant; i++)
            habitaciones[i].setCosto(habitaciones[i].getCosto() + unMonto);
    }
    
    public String toString() {
        String aux = "";
        for (int i=0; i<cant; i++)
        if (habitaciones[i].isOcupada()) 
            aux+= "Habitacion "+(i+1)+": "+ habitaciones[i].getCosto() +", ocupada por: "+habitaciones[i].getCliente().getNombre()+", "+habitaciones[i].getCliente().getEdad()+"\n" ;
        else 
            aux+= "Habitacion "+(i+1)+": "+ habitaciones[i].getCosto() +", libre\n";
        return aux;
    }
}
