/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3;

/**
 *
 * @author Win10 1909
 */
public class Ejercicio4 {

    public static void main(String[] args) {
        Hotel h = new Hotel(20);
        Persona mia = new Persona("Mia Peroni",18,47792200);
        Persona mati = new Persona("Matias Chamorro",18,47517241);
        h.reservarHabitacion(mia, 7);
        h.reservarHabitacion(mati,8);
        System.out.println(h.toString());
        
    }
    
}
