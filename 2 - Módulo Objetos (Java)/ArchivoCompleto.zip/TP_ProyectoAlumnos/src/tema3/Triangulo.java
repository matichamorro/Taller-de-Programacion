/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3;

/**
 * @author Matias Chamorro
 */
public class Triangulo {
    private double ladoA;
    private double ladoB;
    private double ladoC;
    private String relleno;
    private String linea;

    public Triangulo(double unLadoA, double unLadoB, double unLadoC, 
    String unRelleno, String unaLinea) {
         ladoA = unLadoA;
         ladoB = unLadoB;
         ladoC = unLadoC;
         relleno = unRelleno;
         linea = unaLinea;
    }
    
    public double getLadoA() {
        return ladoA;
    }
    
    public double getLadoB() {
        return ladoB;
    }
    
    public double getLadoC() {
        return ladoC;
    }
    
    public String getRelleno() {
        return relleno;
    }
    
    public String getLinea() {
        return linea;
    }
    
    public void setLadoA(double unLadoA) {
        ladoA = unLadoA;
    }
    
    public void setLadoB(double unLadoB) {
        ladoB = unLadoB;
    }
    
    public void setLadoC(double unLadoC) {
        ladoC = unLadoC;
    }
    
    public void setRelleno(String unRelleno) {
        relleno = unRelleno;
    }
    
    public void setLinea(String unaLinea) {
        linea = unaLinea;
    }
    
    public double calcularPerimetro() {
        double perimetro = ladoA + ladoB + ladoC;
        return perimetro;
    }
    
    public double calcularArea() {
        double s = (ladoA + ladoB + ladoC)/2.0;
        double area = Math.sqrt(s*(s-ladoA)*(s-ladoB)*(s-ladoC));
        return area;
    }
}
