/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3;

import PaqueteLectura.Lector;
/**
 * @author Win10 1909
 */
public class Ejercicio5 {

    public static void main(String[] args) {
        Circulo c = new Circulo();
        c.setRadio(Lector.leerDouble());
        c.setColorR(Lector.leerString());
        c.setColorL(Lector.leerString());
    }
    
}
