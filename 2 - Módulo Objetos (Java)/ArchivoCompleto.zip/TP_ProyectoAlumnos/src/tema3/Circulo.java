/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3;

/**
 * @author Mati
 */
public class Circulo {
    private double radio;
    private String colorR;
    private String colorL;
    
    public Circulo(double unRadio,String unColorR, String unColorL ) {
        radio = unRadio;
        colorR = unColorR;
        colorL = unColorL;
    }
    
    public Circulo() {
    
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    public String getColorR() {
        return colorR;
    }

    public void setColorR(String colorR) {
        this.colorR = colorR;
    }

    public String getColorL() {
        return colorL;
    }

    public void setColorL(String colorL) {
        this.colorL = colorL;
    }
    
    public double calcularPerimetro() {
        double aux = Math.PI * radio;
        return aux;
    }
    
    public double calcularArea() {
        double aux = Math.PI * (radio * radio);
        return aux;
    }
}
