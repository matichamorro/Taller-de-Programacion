/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3;

/**
 *
 * @author Matias Chamorro
 */
public class Estante {
    private int DimF;
    private int cantLibros;
    private Libro [] libros;
    
    public Estante(int unaCantMax) {
        DimF = unaCantMax;
        cantLibros=0;
        libros = new Libro[DimF];
    }
    
    public Estante() {
        DimF=20;
        cantLibros=0;
        libros = new Libro[DimF];
    }
    
    public int getCantLibros() {
        return cantLibros;
    }
        
    public boolean estaLleno() {
        boolean lleno=false;
        if (cantLibros < DimF)
            lleno=true;
        return lleno;
    }
    
    public void agregarLibro(Libro unLibro) {
        libros[cantLibros] = unLibro;
        cantLibros++;
    }
    
    public Libro buscarLibro(String unTitulo) {
        Libro l = new Libro();
        boolean encontro=false;
        int i=0;
        while ((i<cantLibros)&&(!encontro)) {
            if(libros[i].getTitulo().equals(unTitulo))
                encontro = true;
            i++;
        }
        return libros[i-1];
        
    }
}
